declare function _default(src: any, emitFrame: any, debug: any): Promise<never> | Promise<void> | any;
export default _default;
